#pragma once
#include "Actions.h"
#include <string>
using namespace std;

class Object
{
};

