#pragma once
#include "Object.h"
#include <string>
using namespace std;


class Inventory
{
};

